Html
CSS

L'objectif est de crée un jeu point & clic pour apprendre les différents composants du PCS, il y a :

- une page d'ouverture avec une présentation du jeu ( les règles ) avec une nav, un footer, avec trois liens ( je les ferais )

- Quatres pages composé d'un espace pour mettre une nav et footer ( j'enverrais la première nav et footer sur toute les pages ), d'une image à gauche d'un PC et de composants d'ordinateurs, avec des bouton caché sur l'imagine pour cliquer sur le bon composant décrit sur des règles à droite, dans un cadre qui explique qu'il faut cliquer sur le bon composants avec une question de type : cliquer sur la RAM. Les boutons sont des hyperliens qui amène soit à la page suivante, soit à une page erreur.

- La page erreur est une page composé d'un espace pour la futur nav et footer. à gauche un descriptif de l'élément selectionné ( par exemple si l'utilisateur à cliquer sur le clavier au lieu de l'écran, il y a un descriptif sur le clavier ). et à droite un bouton retry avec des petits éléments d'encouragements

- Puis au bout du 'chemin' ( des quatres pages réussis ), une page avec toujours un espace pour la nav et le footer, un premier paragraphe avec la victoire ! Puis un paragraphe un peu en dessous récapitulatif des composants réussi, et leurs importances, et un bouton retour à la page d'acceuil en gros avec la notion : 'testé les autres jeux !'